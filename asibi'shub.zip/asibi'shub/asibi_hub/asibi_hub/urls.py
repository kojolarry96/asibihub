from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('items/', include('item.urls')),
    path('admin/', admin.site.urls),
    path('dashboard/', include('dashboard.urls')),
    path('inbox/', include('conversation.urls')),
    path('', include('core.urls')),  # Core app handles homepage, login, etc.
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
